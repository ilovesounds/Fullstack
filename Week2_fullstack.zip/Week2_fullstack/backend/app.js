const express = require('express');
const authRoutes = require('./routes/auth');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());
app.use('/api/auth', authRoutes);

app.get('/test', (req, res) => {
  res.send('Test route works!');
});

app.get('/', (req, res) => {
  res.send('Server is up and running and hi!');
});

module.exports = app;

